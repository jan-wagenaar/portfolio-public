## Request shipments

**Description**

As an business to business customer I would like to request shipments
using my own e-commerce package through an integration. In this request
I will provide an origin and destination address, addressee, packet size
and weight. After submitting the request, a shipment is generated. I can
retrieve this shipment, and other shipments, via a second integration
endpoint.

For each shipment an unique code is generated, which follows the
following pattern: DPS028523112862212. This code will be used later to
identify the package.

To request shipments in a secure matter, we need to verify shipment
requests using a client id and token. After validation, a shipment
request may be registered. If validation fails, the request is simply
discarded. A list of valid credentials is provided below.

Shipment addresses will need to be created, if not available.

Since DPS receives thousands of these requests, possibly simultaneously,
we need to guarantee handling of the requests. This means we need to
implement scalability right into our infrastructure.

To simulate the package requests, we created small mock application. We
included the application package below. Run the timer in
RequestGenerator_CS to generate shipment requests.

**Criteria**

-   Requests are processed real-time
-   Requests can only be made authenticated
-   Unique shipment code is created per shipment
-   Invalid requests are moved to an error queue, including an error
    message
-   Able to retrieve a list of shipments including details
