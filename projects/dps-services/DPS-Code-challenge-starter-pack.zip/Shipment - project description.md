# Case

Difficulty: Advanced

Stories: 11

The renowned Dutch Parcel Services has issues to keep up with its
growing demand. Legacy systems are preventing it from scaling up its
business. Changes necessary to attract new drivers and customers take
months to implement. This means astronomical costs in both maintenance
and development. For example, of every dollar paid for a parcel, \$0.28
of it was spent on IT infrastructure. One example why DPS needs to spend
so much, is due the use of COBOL in most of its core systems. The
consultants to develop these systems, if available at all, charge
excessive amounts. This is threatening for DPS revenue. Last year DPS
lost 1.19 million in profit. Shareholders are warning this year will be
the same, if no immediate actions are undertaken. In short, DPS' core
systems needs to change, and they need to change fast.

Recently, DPS came into contact with Outsystems. They have asked you to
create a [MVP](https://www.agilealliance.org/glossary/mvp/) for some
their core systems. In short they want to receive request to send
parcels from business customers, track and update parcels throughout
their journey and expose that to their customers.

As the board is a bit sceptical about Outsystems capabilities, it's your
job to convince them. Since DPS is a multinational, architecture is
important. Before jumping into development, take a step back and
consider all the parts required. Read all the stories, map them to
larger concepts and consider how they impact each other. This ensures
that DPS is able to grow as promised.

DPS is mainly focused on delivery parcels, since the rise of e-commerce.
We'll be building application to support this process. In short this
process looks like this:

![](./Shipment - project description.png){width="6.3in" height="2.482638888888889in"}

Each part of this process will be described in one or multiple stories.

DPS requires high performance applications. Each day, DPS delivers
roughly 560.000 parcels to their customers. All these packages needs to
be registered, tracked and planned properly. Both logic and interfaces
need to be efficient. Fault tolerance is also a topic to consider. Not
every parcels journey is completed the first try. Packages might get
lost, are send to incorrect addresses or exceed weight limits. Log
errors, implement business checks and provide ways for employees to
resolve errors.

Good luck and have fun while completing this challenge!